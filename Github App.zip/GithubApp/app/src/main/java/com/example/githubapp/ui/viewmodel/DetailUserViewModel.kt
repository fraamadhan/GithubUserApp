package com.example.githubapp.ui.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.githubapp.data.response.GithubUserDetailResponse
import com.example.githubapp.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailUserViewModel : ViewModel() {
    private val _user = MutableLiveData<GithubUserDetailResponse>()
    val user : LiveData<GithubUserDetailResponse> = _user

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading : LiveData<Boolean> = _isLoading

    companion object{
        private const val DETAILTAG = "DetailUserViewModel"
    }

    fun getDetailUser(usn : String = ""){
        _isLoading.value = true
        val client = ApiConfig.getApiService().getDetailUser(usn)
        client.enqueue(object : Callback<GithubUserDetailResponse> {
            override fun onResponse(
                call: Call<GithubUserDetailResponse>,
                response: Response<GithubUserDetailResponse>
            ) {
                _isLoading.value = false
                if(response.isSuccessful){
                    _user.value = response.body()
                }
                else{
                    Log.e(DETAILTAG, "onFailure : ${response.message()}")
                }
            }

            override fun onFailure(call: Call<GithubUserDetailResponse>, t: Throwable) {
                _isLoading.value = false
                Log.e(DETAILTAG, "onFailure : ${t.message.toString()}")
            }

        })
    }

}