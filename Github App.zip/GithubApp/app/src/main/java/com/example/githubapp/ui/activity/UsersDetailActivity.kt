package com.example.githubapp.ui.activity

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.githubapp.R
import com.example.githubapp.data.response.GithubUserDetailResponse
import com.example.githubapp.databinding.ActivityUsersDetailBinding
import com.example.githubapp.ui.SectionPagerAdapter
import com.example.githubapp.ui.viewmodel.DetailUserViewModel
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class UsersDetailActivity : AppCompatActivity() {

    companion object{
        const val EXTRA_DATA = "extra_data"
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.followers,
            R.string.followings,
        )
    }

    private lateinit var binding : ActivityUsersDetailBinding
    private val detailUserViewModel by viewModels<DetailUserViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUsersDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val username = intent.getStringExtra(EXTRA_DATA)

        detailUserViewModel.isLoading.observe(this){
            showLoading(it)
        }
        detailUserViewModel.user.observe(this){
                user ->
            setDataUser(user)
        }

        detailUserViewModel.getDetailUser(username!!)

        val sectionPagerAdapter = SectionPagerAdapter(this, username)
        val viewPager : ViewPager2 = binding.viewPager
        viewPager.adapter = sectionPagerAdapter
        val tabs : TabLayout = binding.tabs
        TabLayoutMediator(tabs, viewPager){
                tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

    }

    private fun setDataUser(user : GithubUserDetailResponse){
        Glide.with(this)
            .load(user.avatarUrl)
            .circleCrop()
            .into(binding.userDetailsProfileimg)

        binding.userFullNameDetail.text = user.name
        binding.usernameDetail.text = user.login
        binding.followers.text = String.format(getString(R.string.total_followers), user.followers)
        binding.following.text = String.format(getString(R.string.total_followings), user.following)
    }

    private fun showLoading(isLoading : Boolean){
        if(isLoading){
            binding.progressBar.visibility = View.VISIBLE
        }
        else{
            binding.progressBar.visibility = View.INVISIBLE
        }
    }
}